public interface EmployeeInterface {
    public abstract void calcMonthlyBonus();
}
